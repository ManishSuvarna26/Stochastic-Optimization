function elitePopulation = InsertBestIndividual(population,previousBestIndividual,nCopiesOfBestIndividual)
  population(nCopiesOfBestIndividual,:) = previousBestIndividual;
  elitePopulation = population;
    